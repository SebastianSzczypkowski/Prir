package forkjoin;

public interface Sort {
    void sort(int[] tab);
}
